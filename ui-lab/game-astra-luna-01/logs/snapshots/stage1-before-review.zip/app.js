const FIXTURE_URL = "../experiments/social-game/fixtures/content.json";
const ASSET_ROOT = "../experiments/social-game/";

const app = document.querySelector("#app");
let content = null;

const escapeHTML = (value = "") => String(value)
  .replaceAll("&", "&amp;")
  .replaceAll("<", "&lt;")
  .replaceAll(">", "&gt;")
  .replaceAll('"', "&quot;")
  .replaceAll("'", "&#039;");

const assetURL = (path) => `${ASSET_ROOT}${path}`;
const characterById = (id) => content.characters.find((character) => character.id === id);
const guideById = (id) => content.guides.find((guide) => guide.id === id);
const eventById = (id) => content.events.find((event) => event.id === id);
const threadById = (id) => content.threads.find((thread) => thread.id === id);

function parseRoute() {
  const raw = window.location.hash.slice(1) || "home";
  const [path, queryString = ""] = raw.split("?");
  return { path, query: new URLSearchParams(queryString) };
}

function navItems() {
  return [
    ["home", "ホーム"],
    ["characters", "キャラ図鑑"],
    ["guides", "攻略記事"],
    ["community", "掲示板"],
    ["party", "編成ツール"],
  ];
}

function headerTemplate(route) {
  const active = route.path.startsWith("character/") || route.path === "characters" ? "characters" : route.path.split("/")[0];
  return `
    <header class="site-header">
      <div class="header-inner">
        <a class="brand" href="#home" aria-label="星環クロニクル攻略室 ホーム">
          <span class="brand-mark" aria-hidden="true">✦</span>
          <span class="brand-copy">
            <span class="brand-title">星環クロニクル攻略室</span>
            <span class="brand-subtitle">SEIKAN CHRONICLE / FIELD NOTES</span>
          </span>
        </a>
        <nav class="primary-nav" id="primary-nav" aria-label="主要メニュー">
          <ul>
            ${navItems().map(([path, label]) => `<li><a href="#${path}" ${active === path ? 'aria-current="page"' : ""}>${label}</a></li>`).join("")}
          </ul>
        </nav>
        <div class="header-actions">
          <button class="menu-button" type="button" data-action="toggle-menu" aria-controls="primary-nav" aria-expanded="false" aria-label="メニューを開く">☰</button>
        </div>
        <form class="header-search" data-search-form>
          <label for="header-search-input">サイト内検索</label>
          <input id="header-search-input" name="q" type="search" placeholder="キャラ・記事を検索" autocomplete="off" />
          <button class="icon-button" type="submit" aria-label="検索">⌕</button>
        </form>
      </div>
      <div class="status-strip">
        <div class="header-inner status-inner">
          <p><span class="gold-text">●</span> 架空ゲームのローカルデモ　/　基準時刻 2026.09.07 21:00 JST</p>
          <p><a class="status-link" href="#bookmarks">保存一覧を見る →</a></p>
        </div>
      </div>
    </header>`;
}

function footerTemplate() {
  return `
    <footer class="site-footer">
      <div class="footer-inner">
        <div>
          <p class="footer-brand">星環クロニクル攻略室</p>
          <p>架空ゲームの学習用デモ。実在のゲーム・運営とは関係ありません。</p>
        </div>
        <div class="footer-links">
          <a href="#community">利用ルール</a>
          <a href="#bookmarks">保存データ</a>
          <a href="#home">素材出典</a>
        </div>
      </div>
    </footer>`;
}

function breadcrumbs(items) {
  return `<nav aria-label="パンくず"><ol class="breadcrumb-list">${items.map((item, index) => `<li>${index < items.length - 1 && item.href ? `<a href="${item.href}">${escapeHTML(item.label)}</a>` : escapeHTML(item.label)}</li>`).join("")}</ol></nav>`;
}

function characterCard(character, extraClass = "") {
  return `
    <a class="character-card ${extraClass}" href="#character/${character.id}">
      <img src="${assetURL(character.image)}" alt="${escapeHTML(character.name)}のキャラクターアイコン" loading="lazy" />
      <span class="character-info">
        <span class="character-name">${escapeHTML(character.name)}</span>
        <span class="character-meta">${escapeHTML(character.element)} / ${escapeHTML(character.role)}</span>
        <span class="character-rating">★ ${escapeHTML(character.rating.toFixed(1))}</span>
      </span>
    </a>`;
}

function guideRow(guide) {
  return `
    <li>
      <a class="guide-link" href="#guide/${guide.id}">
        <span>
          <span class="guide-title">${escapeHTML(guide.title)}</span>
          <span class="guide-summary">${escapeHTML(guide.summary)}</span>
        </span>
        <span class="guide-meta"><span class="tag">${escapeHTML(guide.category)}</span><time datetime="${guide.updated}">${escapeHTML(guide.updated.replaceAll("-", "."))}</time></span>
      </a>
    </li>`;
}

function threadRow(thread) {
  const replies = thread.replies?.length ?? 0;
  return `
    <a class="thread-row" href="#thread/${thread.id}">
      <span><span class="thread-title">${escapeHTML(thread.title)}</span><span class="thread-sub">${escapeHTML(thread.category)}　${escapeHTML(thread.author)}</span></span>
      <span class="thread-count">返信 ${replies}</span>
    </a>`;
}

function homeView() {
  const featuredEvent = eventById("e01");
  const featuredGuides = content.guides.slice(0, 4);
  const featuredCharacters = content.characters.slice(0, 4);
  const featuredThreads = content.threads.slice(0, 3);
  return `
    <div class="page-heading">
      <div>
        <p class="eyebrow">FIELD NOTES / 2026.09.07</p>
        <h1>今やることから、<br />星環の奥行きへ。</h1>
        <p class="lede">開催中のイベント、手持ちキャラの使い方、攻略で詰まった疑問を、迷わず次の一手につなげる攻略室です。</p>
      </div>
      <div class="heading-aside"><strong>03</strong>開催中のイベント</div>
    </div>

    <div class="home-grid">
      <div class="stack">
        <section class="paper-panel event-feature" aria-labelledby="event-heading">
          <div class="event-image"><img src="${assetURL(featuredEvent.image)}" alt="${escapeHTML(featuredEvent.title)}のイベントイメージ" /></div>
          <div class="event-copy">
            <div class="panel-kicker"><p>EVENT / PICK UP</p><span class="status-pill">${escapeHTML(featuredEvent.status)}</span></div>
            <h2 id="event-heading">${escapeHTML(featuredEvent.title)}</h2>
            <p>${escapeHTML(featuredEvent.description)}</p>
            <div class="event-meta"><span>${escapeHTML(featuredEvent.start.replaceAll("-", "."))} — ${escapeHTML(featuredEvent.end.replaceAll("-", "."))}</span><span>報酬 ${escapeHTML(featuredEvent.rewards[0])}</span></div>
            <div class="action-row"><a class="button-link" href="#event/${featuredEvent.id}">イベント詳細を見る <span aria-hidden="true">→</span></a><a class="subtle-button" href="#guide/${featuredEvent.guide}">攻略記事</a></div>
          </div>
        </section>

        <section class="section-block" aria-labelledby="guides-heading">
          <div class="section-head"><h2 id="guides-heading">攻略の入口</h2><a href="#guides">8記事を見る →</a></div>
          <ul class="guide-list">${featuredGuides.map(guideRow).join("")}</ul>
        </section>

        <section class="section-block" aria-labelledby="roster-heading">
          <div class="section-head"><h2 id="roster-heading">まず見る4人</h2><a href="#characters">図鑑をひらく →</a></div>
          <div class="character-preview-grid">${featuredCharacters.map((character) => characterCard(character)).join("")}</div>
        </section>
      </div>

      <aside class="stack">
        <section class="paper-panel panel-pad" aria-labelledby="start-heading">
          <div class="panel-kicker"><p>START HERE</p><span class="tag tag--gold">3分で確認</span></div>
          <h2 id="start-heading">迷ったらこの順番</h2>
          <p class="update-note">新しく始めた旅人向けに、読む場所を3つに絞りました。</p>
          <ul class="quick-list">
            <li><a href="#guide/g01"><span><strong>01</strong>　最初の3日</span></a></li>
            <li><a href="#characters"><span><strong>02</strong>　手持ちを確認</span></a></li>
            <li><a href="#party"><span><strong>03</strong>　4枠を組む</span></a></li>
          </ul>
        </section>
        <section class="paper-panel panel-pad" aria-labelledby="community-heading">
          <div class="section-head"><h2 id="community-heading">最近の相談</h2><a href="#community">掲示板へ →</a></div>
          <div class="community-preview">${featuredThreads.map(threadRow).join("")}</div>
        </section>
        <section class="paper-panel panel-pad">
          <p class="eyebrow">更新情報</p>
          <p class="update-note"><strong>2026.09.07</strong><br />星環祭の報酬交換ガイドを追加しました。数値は固定データに準拠しています。</p>
          <a class="action-link" href="#bookmarks">保存した記事を確認 →</a>
        </section>
      </aside>
    </div>`;
}

function directoryView() {
  return `
    ${breadcrumbs([{ label: "ホーム", href: "#home" }, { label: "キャラ図鑑" }])}
    <div class="page-heading">
      <div><p class="eyebrow">CHARACTER ARCHIVE / 12 RECORDS</p><h1>キャラ図鑑</h1><p class="lede">属性と役割から、いまの編成に必要な一人を探します。画像と能力の詳細は同じ固定データから表示しています。</p></div>
      <div class="heading-aside"><strong id="character-count">12</strong>件の記録</div>
    </div>
    <section class="directory-toolbar" aria-label="キャラの絞り込み">
      <div class="field"><label for="character-query">名前で検索</label><input id="character-query" type="search" placeholder="例：アカリ" data-character-filter="query" /></div>
      <div class="field"><label for="element-filter">属性</label><select id="element-filter" data-character-filter="element"><option value="">すべて</option><option>火</option><option>水</option><option>風</option><option>光</option></select></div>
      <div class="field"><label for="role-filter">役割</label><select id="role-filter" data-character-filter="role"><option value="">すべて</option><option>攻撃</option><option>支援</option><option>防御</option></select></div>
      <div class="field"><label for="sort-filter">並べ替え</label><select id="sort-filter" data-character-filter="sort"><option value="name">名前順</option><option value="rating">評価順</option></select></div>
      <button class="subtle-button" type="button" data-action="reset-character-filter">条件をリセット</button>
    </section>
    <p class="result-line" id="character-result-line" aria-live="polite"><strong>12件</strong>を表示中</p>
    <div class="character-grid" id="character-grid"></div>`;
}

function detailView(character) {
  const partners = character.partners.map(characterById).filter(Boolean);
  return `
    ${breadcrumbs([{ label: "ホーム", href: "#home" }, { label: "キャラ図鑑", href: "#characters" }, { label: character.name }])}
    <section class="paper-panel detail-hero" aria-labelledby="detail-title">
      <div class="detail-portrait"><img src="${assetURL(character.image)}" alt="${escapeHTML(character.name)}のキャラクターアイコン" /></div>
      <div class="detail-summary">
        <p class="eyebrow">CHARACTER RECORD / ${escapeHTML(character.id.toUpperCase())}</p>
        <h1 id="detail-title">${escapeHTML(character.name)}</h1>
        <p class="detail-subtitle">${escapeHTML(character.element)}属性・${escapeHTML(character.role)}　/　${escapeHTML(character.rarity)}</p>
        <div class="detail-tags"><span class="tag">${escapeHTML(character.element)}</span><span class="tag">${escapeHTML(character.role)}</span><span class="tag tag--gold">${escapeHTML(character.rarity)}</span></div>
        <div class="rating-block"><span class="rating-number">${escapeHTML(character.rating.toFixed(1))}</span><span class="rating-label">総合評価 / 固定データ</span></div>
        <p class="detail-subtitle">最初の編成では、役割の異なる仲間と組ませると持ち味を発揮します。</p>
        <div class="action-row"><a class="button-link" href="#party">編成に追加する <span aria-hidden="true">→</span></a><a class="subtle-button" href="#characters">図鑑へ戻る</a></div>
      </div>
    </section>
    <div class="detail-grid">
      <section class="paper-panel panel-pad" aria-labelledby="ability-heading">
        <div class="panel-kicker"><p>ABILITY PROFILE</p><span class="tag">${escapeHTML(character.id)}</span></div>
        <h2 id="ability-heading">能力の見取り図</h2>
        <div class="stat-grid"><div class="stat"><span class="stat-label">攻撃</span><strong class="stat-value">${escapeHTML(character.attack.toLocaleString("ja-JP"))}</strong></div><div class="stat"><span class="stat-label">HP</span><strong class="stat-value">${escapeHTML(character.hp.toLocaleString("ja-JP"))}</strong></div></div>
        <div class="rule"></div>
        <div class="skill-callout"><strong>固有スキル</strong><p>${escapeHTML(character.skill)}</p></div>
      </section>
      <section class="paper-panel panel-pad" aria-labelledby="materials-heading">
        <div class="panel-kicker"><p>GROWTH NOTES</p><span class="tag tag--gold">育成</span></div>
        <h2 id="materials-heading">必要素材</h2>
        <ul class="materials">${character.materials.map((material) => `<li><span>${escapeHTML(material.split("×")[0])}</span><strong>×${escapeHTML(material.split("×")[1])}</strong></li>`).join("")}</ul>
        <p class="muted" style="font-size: 13px;">素材の基準値は共通フィクスチャに固定されています。</p>
      </section>
    </div>
    <section class="paper-panel panel-pad section-block" aria-labelledby="partners-heading">
      <div class="panel-kicker"><p>PARTY SYNERGY</p><span class="tag">関連キャラ</span></div>
      <h2 id="partners-heading">相性のよい記録</h2>
      <p class="muted">固定データ上のパートナー候補です。気になるキャラの詳細へ移動できます。</p>
      <div class="partners">${partners.map((partner) => `<a class="partner" href="#character/${partner.id}"><img src="${assetURL(partner.image)}" alt="" loading="lazy" /><span>${escapeHTML(partner.name)}　${escapeHTML(partner.role)}</span></a>`).join("")}</div>
    </section>`;
}

function guideDetailView(guide) {
  return `
    ${breadcrumbs([{ label: "ホーム", href: "#home" }, { label: "攻略記事", href: "#guides" }, { label: guide.title }])}
    <article class="under-construction">
      <p class="eyebrow">GUIDE RECORD / ${escapeHTML(guide.id.toUpperCase())}</p>
      <h1>${escapeHTML(guide.title)}</h1>
      <p>${escapeHTML(guide.summary)}</p>
      <span class="tag">${escapeHTML(guide.category)}　${escapeHTML(guide.updated.replaceAll("-", "."))}</span>
      <div class="rule"></div>
      <p><strong>記事本文の整形は次ステージで実装予定です。</strong> このリンクは固定データに対応した意味のある下書き状態を表示しています。</p>
      <div class="action-row"><a class="button-link" href="#characters">関連キャラを見る</a><a class="subtle-button" href="#guides">記事一覧へ戻る</a></div>
    </article>`;
}

function searchView(term) {
  const normalized = term.trim().toLocaleLowerCase("ja");
  const results = [];
  if (normalized) {
    content.characters.forEach((item) => {
      if ([item.name, item.element, item.role, item.skill].join(" ").toLocaleLowerCase("ja").includes(normalized)) results.push({ type: "キャラ", title: item.name, copy: `${item.element}・${item.role} / ${item.skill}`, href: `#character/${item.id}` });
    });
    content.guides.forEach((item) => {
      if ([item.title, item.summary, item.category, ...item.sections.map((section) => section.body)].join(" ").toLocaleLowerCase("ja").includes(normalized)) results.push({ type: "攻略記事", title: item.title, copy: item.summary, href: `#guide/${item.id}` });
    });
    content.threads.forEach((item) => {
      if ([item.title, item.body, item.category].join(" ").toLocaleLowerCase("ja").includes(normalized)) results.push({ type: "掲示板", title: item.title, copy: item.body, href: `#thread/${item.id}` });
    });
  }
  return `
    ${breadcrumbs([{ label: "ホーム", href: "#home" }, { label: "検索結果" }])}
    <div class="page-heading"><div><p class="eyebrow">SITE SEARCH / ${normalized ? "RESULT" : "READY"}</p><h1>${normalized ? `「${escapeHTML(term)}」の検索結果` : "サイト内検索"}</h1><p class="lede">キャラ・攻略記事・掲示板のタイトルと本文を横断して検索します。</p></div><div class="heading-aside"><strong>${normalized ? results.length : 0}</strong>${normalized ? "件" : "検索語を入力"}</div></div>
    ${normalized ? (results.length ? `<div class="search-results">${results.map((result) => `<a class="search-result" href="${result.href}"><span class="search-result-type">${escapeHTML(result.type)}</span><div class="search-result-title">${escapeHTML(result.title)}</div><div class="search-result-copy">${escapeHTML(result.copy)}</div></a>`).join("")}</div>` : `<div class="empty-state"><strong>該当する記録はありません。</strong><p>検索語を変えて、もう一度お試しください。</p><a class="subtle-button" href="#home">ホームへ戻る</a></div>`) : `<div class="paper-panel panel-pad"><p class="muted">ヘッダーの検索欄から、たとえば「結晶」や「アカリ」を検索できます。</p></div>`}`;
}

function placeholderView(path) {
  const labels = { guides: "攻略記事", community: "掲示板", party: "編成ツール", events: "イベント", bookmarks: "保存一覧" };
  const label = labels[path] || "ページ";
  return `
    ${breadcrumbs([{ label: "ホーム", href: "#home" }, { label }])}
    <section class="under-construction">
      <span class="construction-mark" aria-hidden="true">✦</span>
      <p class="eyebrow">CHECKPOINT / STAGE 2+</p>
      <h1>${escapeHTML(label)}</h1>
      <p>この入口はつながっています。${escapeHTML(label)}の本体機能は次ステージで実装予定ですが、現在の固定データと導線を壊さない形で準備中です。</p>
      <div class="rule"></div>
      <p class="muted">ホーム、キャラ図鑑、キャラ詳細 c01 はこのチェックポイントで利用できます。</p>
      <div class="route-list"><a class="subtle-button" href="#home">ホームへ</a><a class="subtle-button" href="#characters">キャラ図鑑を見る</a></div>
    </section>`;
}

function notFoundView(label = "お探しの記録") {
  return `
    ${breadcrumbs([{ label: "ホーム", href: "#home" }, { label: "見つかりません" }])}
    <section class="empty-state"><h1>${escapeHTML(label)}が見つかりません</h1><p>URLを確認するか、図鑑から記録を選んでください。</p><a class="subtle-button" href="#characters">図鑑へ戻る</a></section>`;
}

function renderCharacters() {
  const grid = document.querySelector("#character-grid");
  const query = document.querySelector("[data-character-filter='query']")?.value.trim().toLocaleLowerCase("ja") ?? "";
  const element = document.querySelector("[data-character-filter='element']")?.value ?? "";
  const role = document.querySelector("[data-character-filter='role']")?.value ?? "";
  const sort = document.querySelector("[data-character-filter='sort']")?.value ?? "name";
  const filtered = content.characters.filter((character) => {
    const matchesQuery = !query || [character.name, character.skill].join(" ").toLocaleLowerCase("ja").includes(query);
    return matchesQuery && (!element || character.element === element) && (!role || character.role === role);
  }).sort((a, b) => sort === "rating" ? b.rating - a.rating : a.name.localeCompare(b.name, "ja"));
  grid.innerHTML = filtered.length ? filtered.map((character) => characterCard(character, "directory-card")).join("") : `<div class="empty-state" style="grid-column: 1 / -1;"><strong>条件に一致するキャラはいません。</strong><p>条件を変えるか、リセットして12件に戻してください。</p></div>`;
  const line = document.querySelector("#character-result-line");
  if (line) line.innerHTML = `<strong>${filtered.length}件</strong>を表示中`;
  const count = document.querySelector("#character-count");
  if (count) count.textContent = filtered.length;
}

function bindInteractions(route) {
  document.querySelector("[data-search-form]")?.addEventListener("submit", (event) => {
    event.preventDefault();
    const term = new FormData(event.currentTarget).get("q")?.toString().trim() ?? "";
    if (!term) return document.querySelector("#header-search-input")?.focus();
    window.location.hash = `search?q=${encodeURIComponent(term)}`;
  });
  document.querySelector("[data-action='toggle-menu']")?.addEventListener("click", (event) => {
    const button = event.currentTarget;
    const nav = document.querySelector("#primary-nav");
    const open = nav?.classList.toggle("is-open") ?? false;
    button.setAttribute("aria-expanded", String(open));
    button.setAttribute("aria-label", open ? "メニューを閉じる" : "メニューを開く");
    button.textContent = open ? "×" : "☰";
  });
  document.querySelectorAll(".primary-nav a").forEach((link) => link.addEventListener("click", closeMenu));
  document.querySelectorAll("[data-character-filter]").forEach((control) => control.addEventListener(control.matches("input") ? "input" : "change", renderCharacters));
  document.querySelector("[data-action='reset-character-filter']")?.addEventListener("click", () => {
    document.querySelectorAll("[data-character-filter]").forEach((control) => { control.value = control.dataset.characterFilter === "sort" ? "name" : ""; });
    renderCharacters();
  });
  if (route.path === "characters") renderCharacters();
}

function closeMenu() {
  const nav = document.querySelector("#primary-nav");
  const button = document.querySelector("[data-action='toggle-menu']");
  nav?.classList.remove("is-open");
  button?.setAttribute("aria-expanded", "false");
  if (button) { button.setAttribute("aria-label", "メニューを開く"); button.textContent = "☰"; }
}

function viewForRoute(route) {
  if (route.path === "home") return homeView();
  if (route.path === "characters") return directoryView();
  if (route.path.startsWith("character/")) {
    const character = characterById(route.path.split("/")[1]);
    return character ? detailView(character) : notFoundView("キャラ");
  }
  if (route.path.startsWith("guide/")) {
    const guide = guideById(route.path.split("/")[1]);
    return guide ? guideDetailView(guide) : notFoundView("攻略記事");
  }
  if (route.path.startsWith("thread/")) return notFoundView("スレッド");
  if (route.path === "search") return searchView(route.query.get("q") ?? "");
  if (["guides", "community", "party", "events", "bookmarks"].includes(route.path)) return placeholderView(route.path);
  return notFoundView();
}

function render() {
  if (!content) return;
  const route = parseRoute();
  closeMenu();
  app.innerHTML = `${headerTemplate(route)}<main id="main-content"><div class="main-inner">${viewForRoute(route)}</div></main>${footerTemplate()}`;
  bindInteractions(route);
  document.title = route.path.startsWith("character/") && characterById(route.path.split("/")[1]) ? `${characterById(route.path.split("/")[1]).name} | 星環クロニクル攻略室` : "星環クロニクル攻略室";
  window.scrollTo({ top: 0, behavior: "auto" });
}

async function loadContent() {
  try {
    const response = await fetch(FIXTURE_URL, { cache: "no-store" });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    content = await response.json();
    render();
  } catch (error) {
    app.innerHTML = `<div class="main-inner"><div class="error-state" role="alert"><strong>固定データを読み込めませんでした。</strong><p>ローカルサーバー経由で再読み込みしてください。(${escapeHTML(error.message)})</p></div></div>`;
  }
}

window.addEventListener("hashchange", render);
window.addEventListener("keydown", (event) => { if (event.key === "Escape") closeMenu(); });
loadContent();
